package com.example.beercatalogservice

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class BeerCatalogServiceApplication

fun main(args: Array<String>) {
    SpringApplication.run(BeerCatalogServiceApplication::class.java, *args)
}
